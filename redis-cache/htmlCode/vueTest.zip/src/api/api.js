import axios from 'axios'
import { Message, Loading } from 'element-ui';
import qs from 'qs'

axios.defaults.timeout = 5000;
// axios.defaults.baseURL = 'http://app.test.wemew.com';
// axios.defaults.baseURL = 'http://192.168.6.27:8083';//本地
axios.defaults.baseURL = 'http://127.0.0.1:8083';




//同时发送多次请求处理
let needLoadingRequestCount = 0
function tryShowFullScreenLoading() {
  if (needLoadingRequestCount === 0) {
    startLoading()
  }
  needLoadingRequestCount++ 
}
function tryHideFullScreenLoading() {
  if (needLoadingRequestCount <= 0) return
  
  needLoadingRequestCount--
  if (needLoadingRequestCount === 0) {
    endLoading()
  }
}
//loading初始化与关闭
let loading = ''
function startLoading() {
  loading = Loading.service({
    lock: true,
    text: '为您加载...',
    background: 'rgba(0, 0, 0, 0.7)',
    spinner:'el-icon-loading'
  })
}
function endLoading() {
  loading.close()
}


// axios请求拦截器
axios.interceptors.request.use((config) => {
  if(config.url!='/mpAssistant/getFeedMessages'){
    tryShowFullScreenLoading()
  }else{}
  return config
}, (error) => {
  return Promise.reject(error)
})

// axios响应拦截器
axios.interceptors.response.use(function (response) {
  tryHideFullScreenLoading()
  if(response.data.status==1000){
    return response.data;
  }else{
    Message({message: response.data.message,type: 'error',center: true})
  }
  }, function (err) {
    tryHideFullScreenLoading()
      if (err) {
        if(!!err.response){
            switch (err.response.status) {
              case 400: Message({message: '请求错误(400)',type: 'error',center: true}); break;
              case 401: Message({message: '未授权，请重新登录(401)',type: 'error',center: true}); break;
              case 403: Message({message: '拒绝访问(403)',type: 'error',center: true}); break;
              case 404: Message({message: '请求出错(404)',type: 'error',center: true}); break;
              case 408: Message({message: '请求超时(408)',type: 'error',center: true}); break;
              case 500: Message({message: '服务器错误(500)',type: 'error',center: true}); break;
              case 501: Message({message: '服务未实现(501)',type: 'error',center: true}); break;
              case 502: Message({message: '网络错误(502)',type: 'error',center: true}); break;
              case 503: Message({message: '服务不可用(503)',type: 'error',center: true}); break;
              case 504: Message({message: '网络超时(504)',type: 'error',center: true}); break;
              case 505: Message({message: 'HTTP版本不受支持(505)',type: 'error',center: true}); break;
              default: Message({message: `连接出错(${err.response.status})!`,type: 'error',center: true});
            }
        }else{
          Message({message: '接口无返回值',type: 'error',center: true});
        }
      }else{
            Message({message: '连接服务器失败!',type: 'error',center: true});
      }
      return Promise.reject(err);
});

//get
function api(url,data) {
  let config = {headers:{'Content-Type':'appliction/x-www-form-urlencoded'}};
  return axios.get(url,{params:data},config)
}
//post JSON
function apiByPostJson(url,data) {
  let config = {headers:{'Content-Type':'application/json;charset=UTF-8'}};
  return axios.post(url,qs.stringify(data),config)
}
//post QueryString
function apiByPostQueryString(url,data) {
    let params = new URLSearchParams()
    Object.keys(data).forEach(key => {
      params.append(key, data[key])
    })
    return axios.post(url,params)
}
//登录
export function login(data){
  return api(  "/pcUserInfo/login",data)
}
//获取用户列表
export function getUserList(data){
  return api(  "/pcUserInfo/getUserList",data)
}


// 个人日常列表
export function getDynamic(data){
  return apiByPostJson(  "/appapi/getDynamic",data)
}
// 删除版本信息
export function delAppVersion(data){
  return api(  "/pcsys/delAppVersion",data)
}
// 直接上传用户列表进行修改
export function updateCsvUser(data){
  return apiByPostJson(  "/pcsys/updateCsvUser",data)
}
// 获取redis列表
export function getRedisList(data){
  return apiByPostJson(  "/redisList",data)
}

// 获取key操作类型
export function findKeyOpsName(data){
  return apiByPostQueryString(  "/redisManage/findKeyTypeOpsName",data)
}

// redis2级添加
export function addKey(data){
  return apiByPostQueryString(  "/redisManage/addKey",data)
}

// 获取全部model
export function modelAll(data){
  return apiByPostJson(  "/redisManage/modelAll",data)
}
// redis3级添加
export function addSubKey(data){
  return apiByPostQueryString(  "/redisManage/addSubKey",data)
}
// 根据下标获取model
export function findModel(data){
  return apiByPostQueryString(  "/redisManage/findModel",data)
}
// 根据2级id获取下级数据
export function subList(data){
  return apiByPostQueryString(  "/redisManage/subList",data)
}
// 删除
export function deleteList(data){
  return apiByPostQueryString(  "/redisManage/deleteList",data)
}



// //获取约酒详情-搭讪列表
// export function getAccostedList(data){
//   return apiByPostJson(  "/pcsys/accostedList",data)
// }

/*
本地测试接口
export function saveGoods(data){
  return apiByPostJson("/czw/saveGoods",data)
}
export function getGiftList(data){
  return api( "/czw/findGoodsByNormalGoods",data)
}
export function getOneGift(data){
  return api( "/czw/findGoodsByGoodsId",data)
}
export function updateGoods(data){
  return apiByPostJson("/czw/updateGoods",data)
}
export function deleGoods(data){
  return api( "/czw/deleGoods",data)
}
export function updateGoodsSort(data){
  return api( "/czw/updateSort",data)
}
*/
// 上传多张文件签名
export function getSigns(data){
  return apiByPostJson(  "/appCommon/getSigns",data)
}
/*上传文件  --------------------------------------------------------------------------*/
//获取签名
export function getUploadSign(data){
  return api(  "/pcUpload/getSign",data)
}
//文件上传
export function upload(url, data){
  let config = {headers:{'Content-Type':'multipart/form-data'}};
  return axios.post(url,data,config)
}


/**
 * Mocking client-server processing
 */
const _products = [{
    "id": 1,
    "title": "iPad 4 Mini",
    "price": 500.01,
    "inventory": 2
  },
  {
    "id": 2,
    "title": "H&M T-Shirt White",
    "price": 10.99,
    "inventory": 10
  },
  {
    "id": 3,
    "title": "Charli XCX - Sucker CD",
    "price": 19.99,
    "inventory": 5
  }
]

export default {
  getProducts(cb) {
    setTimeout(() => cb(_products), 100)
  },

  buyProducts(products, cb, errorCb) {
    setTimeout(() => {
      // simulate random checkout failure.
      (Math.random() > 0.5 || navigator.userAgent.indexOf('PhantomJS') > -1) ?
      cb(): errorCb()
    }, 100)
  }
}
