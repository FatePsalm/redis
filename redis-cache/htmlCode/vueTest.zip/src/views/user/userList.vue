<template>
	<div class="app-container">
		<el-table v-loading="listLoading" :data="list" element-loading-text="Loading" border fit highlight-current-row>
			<el-table-column align="center" label="ID" width="95">
				<template slot-scope="scope">
					{{ scope.$index }}
				</template>
			</el-table-column>
			<el-table-column label="用户头像" width="80">
				<template slot-scope="scope">
					<img style="width: 60px;height: 60px;border-radius: 50%;" :src="scope.row.userHeadPic" />
				</template>
			</el-table-column>
			<el-table-column label="昵称" width="110" align="center">
				<template slot-scope="scope">
					<span>{{ scope.row.userName }}</span>
				</template>
			</el-table-column>
			<el-table-column label="喵扑号" width="110" align="center">
				<template slot-scope="scope">
					{{ scope.row.nickname }}
				</template>
			</el-table-column>
			<el-table-column class-name="status-col" label="性别" width="110" align="center">
				<template slot-scope="scope">
					{{scope.row.sex==1?'男':'女'}}
				</template>
			</el-table-column>
			<el-table-column class-name="status-col" label="常住地" width="110" align="center">
				<template slot-scope="scope">
					{{scope.row.city}}
				</template>
			</el-table-column>
			
			<el-table-column align="center" prop="createTime" :formatter="dateFormat"  label="注册时间" width="200"></el-table-column>
			
			<el-table-column class-name="status-col" label="操作" width="110" align="center">
				<template slot-scope="scope">
					<el-tag :type="scope.row.status | statusFilter">下线</el-tag>
				</template>
			</el-table-column>
		</el-table>
	</div>
</template>

<script>
	import {
		getList
	} from '@/api/table'
	import {
		login,
		getUserList
	} from '@/api/api.js'
	import {
		parseTime,
	} from '@/utils/index.js'
	export default {
		filters: {
			statusFilter(status) {
				const statusMap = {
					published: 'success',
					draft: 'gray',
					deleted: 'danger'
				}
				return statusMap[status]
			}
		},
		data() {
			return {
				list: null,
				listLoading: true,
				requst: {
					currentPage: 1,
					pageSize: 50,
					userType: '',
					serchName: '',
					startTime: '',
					endTime: ''
				},
			}
		},
		created() {
			this.fetchData()
		},
		methods: {
			    // 时间戳转化
			dateFormat(row,column){
				var date = row[column.property];
				if (date === undefined) {
					return "";
				}
				return parseTime(date);
			},
			fetchData() {
				// this.listLoading = true
				//       getList().then(response => {
				//         this.list = response.data.items
				//         this.listLoading = false
				//       })

				getUserList(this.requst).then(res => {
					this.listLoading = false
					if (res && res.resultTrue) {
						this.list = res.resultMsg.userInfos
						// 							const arr = res.resultMsg.userInfos.map(item => {
						// 									return {value: item.telephone + '/' + item.userName,}
						// 							})
						// 							cb(arr)
					}
				})
			}
		}
	}
</script>
