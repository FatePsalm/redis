<template>
  <div class="dashboard-container">
    <el-collapse  accordion>
          <div v-for="(item,index) in  data" :key="index" @click="change(item)">
            <!-- //事件1 -->
              <el-collapse-item style="padding-bottom:0" :title="'text='+item.reveal.text+ '  key='+item.reveal.Key+ '  time='+item.reveal.Time +'s' + '  Type=' + item.reveal.Type + '  redisSource='+item.reveal.redisSource">
                  <el-collapse accordion >
                      <div class="child" v-for="(cell,cellIndex) in  item.ops" :key="cellIndex" @click="cellChange(cell)">  
                        <!-- 事件2 -->
                          <el-collapse-item style="padding-bottom:0">
                              <template slot="title">
                                <div   class="del-content">
                                  <div>{{'opsName='+cell.opsName  + '  remarks='+cell.remarks}}</div>
                                  <div @click.stop>
                                    <el-button class="del" size="mini" type="danger"  icon="el-icon-delete"   @click="deleteList(cell.id)">删除</el-button>
                                  </div>
                                </div>
                              </template>
                              <!-- <div class="third" style="margin-top: 0px"  v-for="(third,thirdIndex) in  cell.redisManage" :key="thirdIndex" @click="thirdChange(third)"> -->
                                <!-- 事件三 -->
                                    <!-- <el-collapse accordion >
                                          <el-collapse-item style="padding-bottom:0" :title="'opsName='+third.opsName  + '  remarks='+third.remarks">
                                              <div class="list">
                                                {{str}}
                                              </div>
                                          </el-collapse-item>
                                  </el-collapse> -->
                              <!-- </div> -->
                                  
                                  <div class="list" v-for="strItem in str" :key="strItem.id">
                                        {{strItem.name}}
                                      <div @click.stop>
                                          <el-button class="del" size="mini" type="danger"  icon="el-icon-delete"   @click="deleteList(strItem.id)">删除</el-button>
                                      </div>
                                  </div>
                                  <div  @click.stop  class="btn-content">
                                    <el-button type="danger"  icon="el-icon-circle-plus-outline"   @click="addRedis(3,cell.id,cell.redisIndex)">添加</el-button>
                                  </div>
                              
                          </el-collapse-item>
                          <!-- <div  @click.stop  class="btn-content">
                            <el-button type="primary" icon="el-icon-circle-plus-outline" v-if="(cellIndex == item.ops.length-1) && (item.ops)"  @click="addRedis(2,item.id,item.reveal.index)">添加</el-button>
                          </div> -->
                      </div>
                  </el-collapse>
                  <div  @click.stop  class="btn-content">
                    <el-button type="primary" icon="el-icon-circle-plus-outline"   @click="addRedis(2,item.id,item.reveal.index)">添加</el-button>
                  </div>
              </el-collapse-item>
          </div>
      </el-collapse>


      <!-- 表单弹窗 -->
      <el-dialog title="表单提交"   :visible.sync="dialogFormVisible">
        <el-form :rules="rules" :model="form" ref="form">

          <el-form-item label="类型" v-if="type==3" prop="modelType" :label-width="formLabelWidth">
            <!-- <el-input v-model="form.name" autocomplete="off"></el-input> -->
            <el-select v-model="form.modelType" @change="chooseModel()" placeholder="请选择">
              <el-option
                v-for="(item,index) in modelOptions"
                :key="index"
                :label="item.name"
                :value="item.keyIndex">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="类型" prop="type" :label-width="formLabelWidth">
            <!-- <el-input v-model="form.name" autocomplete="off"></el-input> -->
            <el-select v-model="form.type" placeholder="请选择">
              <el-option
                v-for="(item,index) in options"
                :key="index"
                :label="item.name"
                :value="item.name">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="备注" prop="note" :label-width="formLabelWidth">
            <el-input v-model="form.note" autocomplete="off"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="closeModel()">取 消</el-button>
          <el-button type="primary" @click="submit('form')">确 定</el-button>
        </div>
      </el-dialog>

  </div>
</template>

<script>
import { mapGetters } from "vuex";
import qs from 'qs'
import {getRedisList,addKey,addSubKey,findKeyOpsName,modelAll,findModel,subList,deleteList} from '@/api/api.js'

let id = 1000;
export default {
  data() {
    return {
      dialogFormVisible:false,    //表单弹窗
      str:[],              //三级内容
      options: [],
      modelOptions:[],
      form: {
        note: '',
        type:'',
        modelType:'',
        redisIndex:''
      },
      id:"",  //操作的redis id
      rules: {
          note: [
            { required: true, message: '请输入备注', trigger: 'blur' },
            { min: 3, max: 30, message: '长度在 3 到 30 个字符', trigger: 'blur' }
          ],
          type: [
            { required: true, message: '请选择类型', trigger: 'change' }
          ],
      },
      type:'',              //2级  3级
      redisIndex:"",      //需要操作的keyIndex
      formLabelWidth: '120px',

      oneIndex:0,
      twoIndex:0,
      activeName:"1",
      cellName:"2",
      thirdName:"3",
      data:[],
      data1: [
        {
          redisModel:
            "RedisModel{index=2, key='admin:id:{{userid}}', className=class com.wemew.rediscache.service.parameter.AdminRedisParament, type='opsForValue', time=0, redisSource=1, text='管理员信息缓存!'}",
          ops: [
            {
              redisManage: [],
              id: "3009ad6e-7d2a-45b0-9681-f1cf8fc66b0f",
              classify: 0,
              status: 1,
              redisIndex: 2,
              createTime: "2020-03-03T11:38:30.048",
              pid: null,
              opsName: "delete",
              remarks: "删除"
            },
            {
              redisManage: [],
              id: "921462c7-b5c2-4ff6-ac65-ea196e26531b",
              classify: 0,
              status: 1,
              redisIndex: 2,
              createTime: "2020-02-28T16:17:19.104",
              pid: null,
              opsName: "set",
              remarks: "添加"
            }
          ]
        },
        {
          redisModel:
            "RedisModel{index=1, key='user:id:{{userid}}', className=class com.wemew.rediscache.service.parameter.UserRedisParament, type='opsForValue', time=0, redisSource=1, text='用户信息缓存!'}",
          ops: [
            {
              redisManage: [
                {
                  redisManage: null,
                  id: "0d57bbc7-110c-4191-a943-04e66ea01906",
                  classify: 1,
                  status: 1,
                  redisIndex: 2,
                  createTime: "2020-02-28T16:21:19.655",
                  pid: "5f85231c-7d65-4f45-8c99-19df4966f3b1",
                  opsName: "set",
                  remarks: "添加"
                }
              ],
              id: "5f85231c-7d65-4f45-8c99-19df4966f3b1",
              classify: 0,
              status: 1,
              redisIndex: 1,
              createTime: "2020-02-28T16:16:58.038",
              pid: null,
              opsName: "set",
              remarks: "添加"
            },
            {
              redisManage: [
                {
                  redisManage: null,
                  id: "62b8941b-3fcf-4611-a76a-476353c4f2bc",
                  classify: 1,
                  status: 1,
                  redisIndex: 2,
                  createTime: "2020-03-03T11:38:54.782",
                  pid: "63a17149-eb76-4950-9647-1e407b4d9f5d",
                  opsName: "delete",
                  remarks: "删除"
                }
              ],
              id: "63a17149-eb76-4950-9647-1e407b4d9f5d",
              classify: 0,
              status: 1,
              redisIndex: 1,
              createTime: "2020-03-03T11:21:54.449",
              pid: null,
              opsName: "delete",
              remarks: "删除"
            }
          ]
        }
      ],
      defaultProps: {
        children: "ops",
        label: "redisModel"
      }
    };
  },
  created() {
    this.getRedisListData()
  },
  methods: {
    // 获取resis列表
    getRedisListData(){
      let data={};
				getRedisList(data).then(res => {
					this.listLoading = false
					if (res && res.status==1000) {
            res.data.map(function (item, index) {
                let str = "index=";
                let startIndex =  item.redisModel.indexOf("index=");
                let newIndex = item.redisModel.slice(startIndex+str.length,startIndex+str.length+1);
                item.newIndex=newIndex*1;
            })
            this.data = res.data
					}
				})
    },
    // 表单提交
    submit:function(formName){
      console.log(this.form)
      let that=  this;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          // alert('submit!');
          if(that.type==2){
            that.addKey();
          }else if(that.type==3){
            that.addSubKey();
          }else{}
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 添加2级key
    addKey:function(){
      let that = this;
      let params={ redisIndex:that.redisIndex,opsName:that.form.type,remarks:that.form.note};
      addKey(params).then(res => {
        that.listLoading = false
        if (res && res.status==1000) {
          // this.data = res.data
          that.$message({
            message: '添加成功',
            type: 'success'
          },function(){

          });
          location.reload();
        }
      })
    },

    //开启弹窗判断    类型
    addRedis:function(type,id,redisIndex){//2级添加3几添加,操作redisid,需要操作的keyIndex
      let that= this;
      that.form={
        note: '',
        type:'',
        modelType:'',
        redisIndex:''
      }
      that.options=[];
      that.modelOptions=[];

      that.dialogFormVisible=true;
      if(type==2){
        that.redisIndex=redisIndex;
        that.type=type;
        that.getOptionsList(redisIndex);
      }else if(type==3){
        // that.redisIndex=redisIndex;
        that.id=id;
        that.type=type;
        that.getModelAll();
      }else{}
    },
    // 获取全部model
    getModelAll:function(){
      let that =this;
      let data = {}
      modelAll(data).then(res => {
        this.listLoading = false
        if (res && res.status==1000) {
            let newArr=[];
            res.data.map(function (item, index) {
                let str = "index=";
                let startIndex =  item.indexOf("index=");
                let newIndex = item.slice(startIndex+str.length,startIndex+str.length+1);
                let newObj={
                  name:item,keyIndex:newIndex*1
                }
                newArr.push(newObj)
            })
            that.modelOptions=newArr

        }
      })
    },
    // 选择model
    chooseModel:function(){
      this.form.type="";
      this.redisIndex=this.form.modelType;
      this.getOptionsList(this.form.modelType)
    },
    // 获取类型列表
    getOptionsList:function(redisIndex){
      let that =this;
      let data = {redisIndex:redisIndex}
      findKeyOpsName(data).then(res => {
        this.listLoading = false
        if (res && res.status==1000) {
            that.options = res.data;
        }
      })
    },
    // 根据二级当前id查询
    findModel:function(id){
      let that =this;
      let data = {pid:id}
      that.str=[];
      subList(data).then(res => {
        this.listLoading = false
        if (res && res.status==1000) {
            let newArr=[]
            res.data.map(function (item, index) {
                let str ='text='+item.Text + '  Key='+item.Key + '  time='+item.Time + 's  type='+item.Type + '  redisSource='+item.redisSource +'  opsName='+ item.opsName+'  remarks='+ item.remarks
                let newObj={name:str,id:item.id}
                newArr.push(newObj)
            })
            that.str=newArr
            console.log(that.str)
        }
      })
    },
    // 添加三级key
    addSubKey:function(){
      let that = this;
      console.log(that.redisIndex,that.form.note,that.form.type,that.id)
      let data = {redisIndex:that.redisIndex,opsName:that.form.type,pid:that.id,remarks:that.form.note}
      addSubKey(data).then(res => {
        this.listLoading = false
        if (res && res.status==1000) {
            // that.options = res.data;
          that.$message({
            message: '添加成功',
            type: 'success'
          },function(){

          });
          location.reload();
        }
      })
    },

    // 关闭表单弹窗
    closeModel:function(){
      let that= this;
      that.dialogFormVisible=false;

    },

    // 删除
    deleteList:function(id){
      let that = this;
      let data = {id:id}
      deleteList(data).then(res => {
        this.listLoading = false
        if (res && res.status==1000) {
            // that.options = res.data;
          that.$message({
            message: '删除成功',
            type: 'success'
          },function(){
          });
            location.reload();
        }
      })
    },

    change(item){
      // let that=this;
      // that.oneIndex = index;
      // console.log(item)
    },
    cellChange(item){
      // let that=this;
      // that.twoIndex = index;
      // console.log(item)
      this.findModel(item.id)
    },
    thirdChange(item){
      // console.log(item)
      // this.findModel(item.redisIndex)
    },
  
  },
  name: "Dashboard",
  computed: {
    ...mapGetters(["name"])
  }
};
</script>

<style lang="scss">
// <style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
  .child{
    padding-left: 25px;
  }
  .third{
    padding-left: 50px;
  }
  .dialog-footer{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .list{
    margin:10px 0px 10px 0;
    line-height: 48px;
    background: #ccc;
  }
  .btn-content{
    display: flex;
    justify-content: center;
  }
  .el-collapse-item__content{
    padding-bottom: 0!important;
  }
  .del-content{
    display: flex;
    justify-content: space-between;
    width: 100%;
    align-items: center;
    .del{
      height: 30px;
    }
  }
</style>
